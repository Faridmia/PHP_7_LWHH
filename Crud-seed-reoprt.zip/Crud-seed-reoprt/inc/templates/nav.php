<p>
    <a href="/crud/index.php?task=report">All Students</a> |
    <a href="/crud/index.php?task=add">Add New Student</a> |
    <a href="/crud/index.php?task=seed">Seed</a>
</p>